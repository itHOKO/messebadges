import cups

def print_to_cups(firstname, lastname, company, printer_name='Kyocera_TASKalfa_3252ci_USB_'):
    conn = cups.Connection()

    with open('/var/www/html/test.txt', 'w') as file:
        file.write(firstname + '\n')
        file.write(lastname + '\n')
        file.write(company)
    
    # Druckauftrag senden
    conn.printFile(printer_name, '/var/www/html/test.txt', 'Test', {})

print_to_cups('Chau', 'Nguyen', 'HOKO')