from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
import cups

def print_to_cups(firstname, lastname, company, printer_name='Kyocera_TASKalfa_3252ci_USB_'):
    conn = cups.Connection()
    generate_pdf_with_formatting(firstname, lastname, company, pdf_file_path='/var/www/html/output.pdf')

    conn.printFile(printer_name, '/var/www/html/output.pdf', 'Test', {})

def split_company_name(company, canvas, y_position):
    splitted_company_name = company.split()
    new_company_name = ''
    new_company_name_gesamt = ''
    while (len(splitted_company_name) > 1):
        length = 0
        while(length + len(splitted_company_name[0]) < 25):
            new_company_name += splitted_company_name.pop(0) + ' '
            if(len(splitted_company_name) == 0):
                break
            length = len(new_company_name)
        new_company_name_gesamt += new_company_name 
        canvas.drawCentredString(167, y_position, f"{new_company_name}")
        canvas.drawCentredString(428, y_position, f"{new_company_name}")
        y_position -= 14
        new_company_name = ''

def generate_pdf_with_formatting(firstname, lastname, company, pdf_file_path='/var/www/html/output.pdf'):
    c = canvas.Canvas(pdf_file_path, pagesize=A4)
    line_height = 25  # Adjust the line height as needed

    # Specify the initial Y-coordinate position
    y_position = 200

    c.setFont("Helvetica-Bold", 20)  # Set font type and size
    # Draw each line of text with adjusted Y-coordinate
    c.drawCentredString(167, y_position, f"{firstname}")
    c.drawCentredString(428, y_position, f"{firstname}")

    y_position -= line_height  # Move to the next line
    c.drawCentredString(167, y_position, f"{lastname}")
    c.drawCentredString(428, y_position, f"{lastname}")

    c.setFont("Helvetica", 12)  # Set font type and size
    y_position -= line_height  # Move to the next line
    split_company_name(company, c, y_position)

    c.save()

# Usage
print_to_cups('Maxi Andreas Johann', 'Mustermann', 'DUSCHL INGENIEURE GmbH und Co. KG Beratende Ingenieure fuer Technische Ausruestung Energietechnik')