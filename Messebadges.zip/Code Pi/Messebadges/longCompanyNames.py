def split_company_name(company):
    splitted_company_name = company.split()
    new_company_name = ''
    new_company_name_gesamt = ''
    while (len(splitted_company_name) > 1):
        length = 0
        while(length + len(splitted_company_name[0]) < 25):
            new_company_name += splitted_company_name.pop(0) + ' '
            if(len(splitted_company_name) == 0):
                break
            length = len(new_company_name)
        new_company_name_gesamt += new_company_name + '\n'
        new_company_name = ''
    return new_company_name_gesamt

print(split_company_name('Excelitas Technologies GmbH & Co. KG / Qioptiq Photonics GmbH & Co. KG'))